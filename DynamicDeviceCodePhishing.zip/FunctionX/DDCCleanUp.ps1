$DeploymentScriptOutputs = @{}
function DDCCleanUp {
    [CmdletBinding()]
    param (
        [string]$DDCfunctionname,
        [string]$DDCtablename
    )
    try {   
        $DDCfunctiomasterkey = 'd9I2c3XAGVoND_72tJAk0Cbpah7nMlr6HTE4fDNan47sAzFuy5fANg=='
        $DDCSTGSASToken = 'sv=2022-11-02&ss=bt&srt=sco&sp=rwdlacuitfx&se=2025-09-11T16:08:54Z&st=2023-09-11T08:08:54Z&spr=https,http&sig=oDRh5IkmzF%2Fbf10iTi4xh%2FMRajhVINC7vpmJ9Zs%2BdDE%3D'
   
        if ($DDCfunctionname -or $DDCtablename) {
            Write-Output "Deleting DDC Function $DDCfunctionname"

            try {

                $URL = "https://ddcattackfunapp.azurewebsites.net/admin/vfs/site/wwwroot/$DDCfunctionname/function.json"
    
                $Params = @{
                    "URI"     = $URL
                    "Method"  = "DELETE"
                    "Headers" = @{
                        "x-functions-key" = "$DDCfunctiomasterkey"
                        "If-Match"        = '*'
                    }
                }
    
                Invoke-RestMethod @Params -UseBasicParsing
            }
            catch {
                write-Output "$DDCfunctionname does not contain function.json"
            }

            try {    
                $URL = "https://ddcattackfunapp.azurewebsites.net/admin/vfs/site/wwwroot/$DDCfunctionname/run.ps1"
    
                $Params = @{
                    "URI"     = $URL
                    "Method"  = "DELETE"
                    "Headers" = @{
                        "x-functions-key" = "$DDCfunctiomasterkey"
                        "If-Match"        = '*'
                    }
                }
    
                Invoke-RestMethod @Params -UseBasicParsing
            }
            catch {
                Write-Output "$DDCfunctionname does not contain run.ps1"
            }

            try {
                # Deleting Storage Account Table
            $StorageContext = New-AzStorageContext -StorageAccountName 'ddcattackstorage' -SasToken $DDCSTGSASToken
            Remove-AzStorageTable -Name $DDCtablename -Context $StorageContext -Force -ErrorAction SilentlyContinue
            }
            catch {
                <#Do this if a terminating exception happens#>
                Write-Output "Table $DDCtablename does note exist "
            }

            
        }

    Write-Output 'Completed the clean-up'
    }
    catch {   
        Write-Output "Entered Exception"
        $DeploymentScriptOutputs["Error"] = $_.Exception.Message
        $DeploymentScriptOutputs["Status"] = "Deployment Failed"
        Write-Output $DeploymentScriptOutputs
    }
}
