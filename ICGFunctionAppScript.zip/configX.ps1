$URL = "https://icgfunction.azurewebsites.net/admin/vfs/home/site/wwwroot/studentX/function.json"

$Params = @{
    "URI"     = $URL
    "Method"  = "PUT"
    "Headers" = @{
    "Content-Type" = "application/octet-stream"
    "x-functions-key" = "RlVuUBW8cP3D-D8XDUoJ9dIjCe-mOxxOSMWKZR_OlLbbAzFuhLjSfw=="
    }
}

$Body = @"
{
  "bindings": [
    {
      "authLevel": "anonymous",
      "type": "httpTrigger",
      "direction": "in",
      "name": "req",
      "methods": [
        "get",
        "post"
      ]
    },
    {
      "type": "http",
      "direction": "out",
      "name": "`$return"
    }
  ]
}
"@

Invoke-RestMethod @Params -UseBasicParsing -Body $Body