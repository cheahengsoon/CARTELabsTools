$DeploymentScriptOutputs = @{}
function ICGCleanUp {
    [CmdletBinding()]
    param (
        [string]$ICGfunctionname,
        [string]$ICGtablename,
        [string]$ICGAppRegName
    )
    try {   
        $ICGfunctionmasterkey = 'RlVuUBW8cP3D-D8XDUoJ9dIjCe-mOxxOSMWKZR_OlLbbAzFuhLjSfw=='
        $ICGSTGSASToken = 'sv=2022-11-02&ss=t&srt=sco&sp=rwdlacu&se=2027-03-27T20:32:26Z&st=2024-03-27T12:32:26Z&spr=https,http&sig=m7GqcPxm8459B423rXX17OpgI%2BVI82y9qTbhRk87e50%3D'
   
        if ($ICGfunctionname -or $ICGtablename -or $ICGAppRegName) {
            Write-Output "Deleting ICT Function $ICGfunctionname"

            try {
    
                $URL = "https://icgfunction.azurewebsites.net/admin/vfs/home/site/wwwroot/$ICGfunctionname/function.json"

                $Params = @{
                    "URI"     = $URL
                    "Method"  = "DELETE"
                    "Headers" = @{
                        "x-functions-key" = "$ICGfunctionmasterkey"
                        "If-Match"        = '*'
                    }
                }
                Invoke-RestMethod @Params -UseBasicParsing -ErrorAction Continue
            }
            catch {
                Write-Output "$ICGfuntionname does contain function.json in ICG Function App"

            }


            try {

                $URL = "https://icgfunction.azurewebsites.net/admin/vfs/home/site/wwwroot/$ICGfunctionname/__init__.py"

                $Params = @{
                    "URI"     = $URL
                    "Method"  = "DELETE"
                    "Headers" = @{
                        "x-functions-key" = "$ICGfunctionmasterkey"
                        "If-Match"        = '*'
                    }
                }
                
                Invoke-RestMethod @Params -UseBasicParsing -ErrorAction SilentlyContinue

            }
            catch {

                Write-Output "$ICGfuntionname does not contain __init__.py in ICG Function App"
            }

            try {
                # Deleting Storage Account Table
            $StorageContext = New-AzStorageContext -StorageAccountName 'icgstorageacc' -SasToken $ICGSTGSASToken
            Remove-AzStorageTable -Name $ICGtablename -Context $StorageContext -Force -ErrorAction SilentlyContinue
    
            }
            catch {
                <#Do this if a terminating exception happens#>
                Write-Output "The table name $ICGtablename does not exist"
            }
            
            try {
                # Deleting the App Regisration
            Remove-AzADApplication -DisplayName $ICGAppRegName -ErrorAction SilentlyContinue
            }
            catch {
                <#Do this if a terminating exception happens#>
                Write-Output "App Registration $ICGAppRegName does not exist"
            }
            
    
        }

    Write-Output 'Completed the clean-up'
    }
    catch {   
        Write-Output "Entered Exception"
        $DeploymentScriptOutputs["Error"] = $_.Exception.Message
        $DeploymentScriptOutputs["Status"] = "Deployment Failed"
        Write-Output $DeploymentScriptOutputs
    }
}
